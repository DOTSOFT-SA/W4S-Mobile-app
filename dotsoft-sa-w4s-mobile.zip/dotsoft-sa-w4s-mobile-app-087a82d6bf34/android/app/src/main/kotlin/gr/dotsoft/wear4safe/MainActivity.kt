package gr.dotsoft.wear4safe

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
