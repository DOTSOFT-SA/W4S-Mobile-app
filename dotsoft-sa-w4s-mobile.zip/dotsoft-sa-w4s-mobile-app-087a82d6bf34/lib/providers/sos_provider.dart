import 'package:flutter/material.dart';

import '../models/sos_model.dart';

class SOSProvider extends ChangeNotifier {
  List<SOSModel> sosList = [];
}
