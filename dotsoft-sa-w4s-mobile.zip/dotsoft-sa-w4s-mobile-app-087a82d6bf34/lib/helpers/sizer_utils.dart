var screenWidth = 0.0;
var screenHeight = 0.0;
